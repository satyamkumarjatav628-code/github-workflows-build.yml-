package com.satyamsir.jarvis

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var answer: TextView
    private lateinit var input: EditText
    private var ttsReady = false
    private val cyan = Color.rgb(58, 220, 255)

    private fun panel(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.rgb(7, 22, 42)); setStroke(1, Color.rgb(24, 116, 164)); cornerRadius = 28f
    }
    private fun txt(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(22, 24, 22, 18)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(2, 7, 17), Color.rgb(4, 25, 48), Color.rgb(2, 7, 17)))
        }
        root.addView(txt("S A T Y A M   S I R", 13f, cyan, true), LinearLayout.LayoutParams(-1, 28))
        root.addView(txt("J A R V I S", 30f, cyan, true), LinearLayout.LayoutParams(-1, 48))
        status = txt("● SYSTEM ONLINE", 12f, Color.rgb(105, 245, 193), true)
        root.addView(status, LinearLayout.LayoutParams(-1, 26))

        val core = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(-1, 0, 1f) }
        val orb = TextView(this).apply {
            text = "◉"; textSize = 112f; gravity = Gravity.CENTER; setTextColor(cyan)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL
                setColor(Color.rgb(5, 26, 52)); setStroke(3, cyan) }
            elevation = 18f
        }
        core.addView(orb, FrameLayout.LayoutParams(240, 240, Gravity.CENTER))
        core.addView(txt("PERSONAL AI CORE  •  READY", 11f, Color.LTGRAY, true),
            FrameLayout.LayoutParams(-1, 34, Gravity.BOTTOM))
        root.addView(core)

        answer = TextView(this).apply {
            text = "नमस्ते Satyam Sir!\\nमैं JARVIS हूँ।\\nमुझसे कुछ भी पूछिए।"
            textSize = 17f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(18, 18, 18, 18); background = panel()
        }
        root.addView(answer, LinearLayout.LayoutParams(-1, 112).apply { bottomMargin = 12 })
        input = EditText(this).apply {
            hint = "यहाँ अपना सवाल लिखें…"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE)
            textSize = 16f; setPadding(16, 10, 16, 10); background = panel()
        }
        root.addView(input, LinearLayout.LayoutParams(-1, 56).apply { bottomMargin = 10 })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val ask = Button(this).apply { text = "ASK JARVIS"; setOnClickListener { askDemo(input.text.toString()) } }
        val voice = Button(this).apply { text = "🎙 VOICE"; setOnClickListener { listen() } }
        listOf(ask, voice).forEach { it.setTextColor(Color.WHITE); it.background = GradientDrawable().apply {
            setColor(Color.rgb(7, 66, 102)); setStroke(1, cyan); cornerRadius = 18f
        } }
        row.addView(ask, LinearLayout.LayoutParams(0, 56, 1f).apply { rightMargin = 7 })
        row.addView(voice, LinearLayout.LayoutParams(0, 56, 1f).apply { leftMargin = 7 })
        root.addView(row)
        root.addView(txt("VOICE INPUT  •  FUTURISTIC MODE", 10f, Color.GRAY), LinearLayout.LayoutParams(-1, 30))
        setContentView(root)
    }

    private fun askDemo(q: String) {
        val question = q.trim()
        answer.text = if (question.isBlank()) "Satyam Sir, pehle apna sawaal likhiye ya VOICE dabaiye."
        else "Satyam Sir, aapka sawaal mila:\\n\\n“$question”\\n\\nOnline AI backend abhi connect karna baaki hai."
        if (ttsReady && question.isNotBlank()) tts.speak("Satyam Sir, aapka sawaal mil gaya. Online AI abhi connect karna baaki hai.", TextToSpeech.QUEUE_FLUSH, null, "reply")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
    }

    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए Satyam Sir…")
        }
        try { startActivityForResult(intent, 101) }
        catch (_: Exception) { answer.text = "इस फोन पर speech recognition सेवा उपलब्ध नहीं है।" }
    }
    @Deprecated("Legacy API retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            input.setText(spoken); askDemo(spoken)
        }
    }
    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            val lang = tts.setLanguage(Locale("hi", "IN"))
            ttsReady = lang != TextToSpeech.LANG_MISSING_DATA && lang != TextToSpeech.LANG_NOT_SUPPORTED
            if (ttsReady) tts.speak("Satyam Sir, JARVIS aa gaya. Main aapki madad ke liye taiyaar hoon.", TextToSpeech.QUEUE_FLUSH, null, "welcome")
        }
    }
    override fun onDestroy() { if (::tts.isInitialized) { tts.stop(); tts.shutdown() }; super.onDestroy() }
}
