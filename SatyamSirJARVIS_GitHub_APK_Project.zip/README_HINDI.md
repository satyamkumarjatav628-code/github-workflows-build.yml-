# Satyam Sir JARVIS — GitHub APK starter

## GitHub Actions se APK
1. GitHub par new repository banayein, preferably Private.
2. Is ZIP ke andar ke saare files/folders repository ke root par upload karein. `.github` folder bhi upload hona chahiye.
3. Commit changes to `main`.
4. Repository → Actions → `Build Satyam Sir JARVIS APK` → Run workflow.
5. Workflow successful hone par run page ke neeche Artifacts mein `SatyamSirJARVIS-debug-apk` download karein.
6. ZIP artifact extract karke `app-debug.apk` Android phone par install karein. Android ki zarurat par “Install unknown apps” permission dein.

## Is starter mein kya hai
- Futuristic dark blue JARVIS screen
- Hindi speech recognition (Android speech service par depend)
- Hindi Text-to-Speech greeting
- GitHub Actions workflow for debug APK

## Important: abhi kya complete nahi hai
- Online AI provider/backend connected nahi hai. ASK JARVIS currently demo response deta hai.
- Vision/photo analysis not implemented yet.
- Always-on “Hey JARVIS” wake word not implemented. Reliable hotword listening needs a dedicated on-device wake-word engine, microphone foreground service, notification, battery tuning and explicit user permission. Android may restrict background microphone use. Is starter mein app khulne par welcome voice aati hai, not on every boot/unlock.
- Phone automation is not implemented; Android permissions and APIs restrict what apps may control.

## Online AI safely add karne ke liye
API key ko Android app ya GitHub source mein commit na karein. A backend HTTPS endpoint should hold the provider key as a server secret, apply rate limits, and return the AI answer to the app. GitHub Actions secrets are for build workflows, not a substitute for a runtime backend.
